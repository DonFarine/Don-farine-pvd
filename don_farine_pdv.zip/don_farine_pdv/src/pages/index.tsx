
import Image from 'next/image'
import products from '../data/products.json'

export default function Home() {
  return (
    <div className="min-h-screen bg-amber-50 p-8 font-sans">
      <div className="text-center mb-8">
        <Image src="/logo.png" alt="Don Farine" width={150} height={150} className="mx-auto" />
        <h1 className="text-4xl font-bold text-orange-900 mt-4">Don Farine</h1>
        <p className="text-lg text-orange-700">Padaria artesanal</p>
        <p className="mt-2 text-base text-orange-600 italic">"Seja muito bem-vindo à Don Farine, onde cada pão conta uma história de carinho e tradição."</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {products.map((product, idx) => (
          <div key={idx} className="bg-white p-4 rounded-2xl shadow-lg">
            <h2 className="text-xl font-semibold text-orange-800">{product.name}</h2>
            <p className="text-orange-600">R$ {product.price.toFixed(2)}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
